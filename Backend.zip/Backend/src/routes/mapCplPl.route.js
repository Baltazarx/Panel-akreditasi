import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';

export const mapCplPlRouter = Router();

const crud = crudFactory({
  table: 'map_cpl_pl',
  idCol: 'id_cpl', // Using id_cpl as the main ID for CRUD, will need to handle compound key for delete if needed
  allowedCols: ['id_cpl', 'id_pl'],
  resourceKey: 'map_cpl_pl',
  softDelete: false,
  withRestore: false,
});

// ---- CRUD ----
mapCplPlRouter.get('/', requireAuth, permit('map_cpl_pl'), crud.list);
mapCplPlRouter.get('/:id(\d+)', requireAuth, permit('map_cpl_pl'), crud.getById);
mapCplPlRouter.post('/', requireAuth, permit('map_cpl_pl'), crud.create);
mapCplPlRouter.put('/:id(\d+)', requireAuth, permit('map_cpl_pl'), crud.update);
mapCplPlRouter.delete('/:id', requireAuth, permit('map_cpl_pl'), crud.remove);
mapCplPlRouter.post('/:id/restore', requireAuth, permit('map_cpl_pl'), crud.restore);
mapCplPlRouter.delete('/:id/hard-delete', requireAuth, permit('map_cpl_pl'), crud.hardRemove);

export default mapCplPlRouter;
