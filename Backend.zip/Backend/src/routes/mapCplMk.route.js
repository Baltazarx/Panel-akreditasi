import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';

export const mapCplMkRouter = Router();

const crud = crudFactory({
  table: 'map_cpl_mk',
  idCol: 'id_cpl', // Using id_cpl as the main ID for CRUD, will need to handle compound key for delete if needed
  allowedCols: ['id_cpl', 'id_mk'],
  resourceKey: 'map_cpl_mk',
  softDelete: false,
  withRestore: false,
});

// Since this is a join table, we might need custom logic for deletion based on both IDs.
// For now, we'll expose standard CRUD, assuming the frontend handles the composite key aspect for deletion or uses custom endpoints.

// ---- CRUD ----
mapCplMkRouter.get('/', requireAuth, permit('map_cpl_mk'), crud.list);
mapCplMkRouter.get('/:id(\d+)', requireAuth, permit('map_cpl_mk'), crud.getById);
mapCplMkRouter.post('/', requireAuth, permit('map_cpl_mk'), crud.create);
mapCplMkRouter.put('/:id(\d+)', requireAuth, permit('map_cpl_mk'), crud.update);
mapCplMkRouter.delete('/:id', requireAuth, permit('map_cpl_mk'), crud.remove);
mapCplMkRouter.post('/:id/restore', requireAuth, permit('map_cpl_mk'), crud.restore);
mapCplMkRouter.delete('/:id/hard-delete', requireAuth, permit('map_cpl_mk'), crud.hardRemove);

export default mapCplMkRouter;
