import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';
import { pool } from '../db.js';
import { makeExportHandler, makeDocAlias, makePdfAlias } from '../utils/exporter.js';

export const tabel2a3KondisiMahasiswaRouter = Router();

// Fungsi ini mengambil data Mahasiswa Baru & Aktif murni dari tabel_2a1
// dan data Lulus & DO dari tabel_2a3.
const listTabel2a3KondisiMahasiswa = async (req, res) => {
  try {
    const sqlMabaAktif = `
      SELECT
        id_tahun, id_unit_prodi, jenis AS jenis_mahasiswa,
        SUM(jumlah_diterima + jumlah_afirmasi + jumlah_kebutuhan_khusus) AS jumlah
      FROM tabel_2a1_mahasiswa_baru_aktif
      WHERE jenis IN ('baru', 'aktif')
      GROUP BY id_tahun, id_unit_prodi, jenis;
    `;

    const sqlLulusDo = `
      SELECT
        id, id_tahun, id_unit_prodi, jml_lulus, jml_do
      FROM tabel_2a3_kondisi_mahasiswa;
    `;

    const [mabaAktifRows] = await pool.query(sqlMabaAktif);
    const [lulusDoRows] = await pool.query(sqlLulusDo);

    const combinedData = [];

    mabaAktifRows.forEach(row => {
      combinedData.push({ ...row, id: null });
    });

    lulusDoRows.forEach(row => {
      combinedData.push({
        id: row.id, id_tahun: row.id_tahun, id_unit_prodi: row.id_unit_prodi,
        jenis_mahasiswa: 'lulus', jumlah: row.jml_lulus || 0
      });
      combinedData.push({
        id: row.id, id_tahun: row.id_tahun, id_unit_prodi: row.id_unit_prodi,
        jenis_mahasiswa: 'mengundurkan_diri', jumlah: row.jml_do || 0
      });
    });

    res.json(combinedData);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal memuat data kondisi mahasiswa' });
  }
};

const crud = crudFactory({
  table: 'tabel_2a3_kondisi_mahasiswa',
  idCol: 'id',
  // PERUBAHAN: Hapus 'jml_aktif' dari kolom yang diizinkan
  allowedCols: [
    'id_unit_prodi',
    'id_tahun',
    'jml_lulus',
    'jml_do',
  ],
  resourceKey: 'tabel_2a3_kondisi_mahasiswa',
  list: listTabel2a3KondisiMahasiswa,
});

// ---- CRUD ----
tabel2a3KondisiMahasiswaRouter.get('/', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.list);
tabel2a3KondisiMahasiswaRouter.get('/:id(\\d+)', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.getById);
tabel2a3KondisiMahasiswaRouter.post('/', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.create);
tabel2a3KondisiMahasiswaRouter.put('/:id(\\d+)', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.update);
tabel2a3KondisiMahasiswaRouter.delete('/:id', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.remove);
tabel2a3KondisiMahasiswaRouter.post('/:id/restore', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.restore);
tabel2a3KondisiMahasiswaRouter.delete('/:id/hard-delete', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.hardRemove);

// ---- EXPORT (DOCX/PDF, TS-aware) ----
const meta = {
  resourceKey: 'tabel_2a3_kondisi_mahasiswa',
  table: 'tabel_2a3_kondisi_mahasiswa',
  // PERUBAHAN: Hapus 'jml_aktif' dari kolom export
  columns: [
    'id',
    'id_unit_prodi',
    'id_tahun',
    'jml_lulus',
    'jml_do',
  ],
  // PERUBAHAN: Hapus 'Jumlah Aktif' dari header export
  headers: [
    'ID',
    'Unit Prodi',
    'Tahun',
    'Jumlah Lulus',
    'Jumlah DO',
  ],
  title: (label) => `Kondisi Mahasiswa — ${label}`,
  orderBy: 'm.id ASC',
};

const exportHandler = makeExportHandler(meta, { requireYear: true });

tabel2a3KondisiMahasiswaRouter.get('/export', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), exportHandler);
tabel2a3KondisiMahasiswaRouter.post('/export', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), exportHandler);
tabel2a3KondisiMahasiswaRouter.get('/export-doc', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makeDocAlias(exportHandler));
tabel2a3KondisiMahasiswaRouter.post('/export-doc', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makeDocAlias(exportHandler));
tabel2a3KondisiMahasiswaRouter.get('/export-pdf', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makePdfAlias(exportHandler));
tabel2a3KondisiMahasiswaRouter.post('/export-pdf', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makePdfAlias(exportHandler));

export default tabel2a3KondisiMahasiswaRouter;