import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';
import { pool } from '../db.js';
import { makeExportHandler, makeDocAlias, makePdfAlias } from '../utils/exporter.js';

export const mataKuliahRouter = Router();

const listMataKuliah = async (req, res) => {
  const q = req.query || {};
  const idKurikulumParam = q.id_kurikulum ?? null;

  let sql = `
    SELECT
      mk.*,
      k.nama_kurikulum
    FROM mata_kuliah mk
    LEFT JOIN kurikulum k ON mk.id_kurikulum = k.id_kurikulum
  `;
  const where = [];
  const params = [];

  if (idKurikulumParam) {
    where.push('mk.id_kurikulum = ?');
    params.push(idKurikulumParam);
  }

  if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
  sql += ` ORDER BY mk.id_mk ASC`;

  try {
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal memuat data mata kuliah' });
  }
};

const crud = crudFactory({
  table: 'mata_kuliah',
  idCol: 'id_mk',
  allowedCols: ['id_kurikulum', 'kode_mk', 'nama_mk', 'sks'],
  resourceKey: 'mata_kuliah',
  list: listMataKuliah,
});

// ---- CRUD ----
mataKuliahRouter.get('/', requireAuth, permit('mata_kuliah'), crud.list);
mataKuliahRouter.get('/:id(\d+)', requireAuth, permit('mata_kuliah'), crud.getById);
mataKuliahRouter.post('/', requireAuth, permit('mata_kuliah'), crud.create);
mataKuliahRouter.put('/:id(\d+)', requireAuth, permit('mata_kuliah'), crud.update);
mataKuliahRouter.delete('/:id', requireAuth, permit('mata_kuliah'), crud.remove);
mataKuliahRouter.post('/:id/restore', requireAuth, permit('mata_kuliah'), crud.restore);
mataKuliahRouter.delete('/:id/hard-delete', requireAuth, permit('mata_kuliah'), crud.hardRemove);

// ---- EXPORT (DOCX/PDF, TS-aware) ----
const meta = {
  resourceKey: 'mata_kuliah',
  table: 'mata_kuliah',
  columns: [
    'id_mk',
    'id_kurikulum',
    'kode_mk',
    'nama_mk',
    'sks',
  ],
  headers: [
    'ID Mata Kuliah',
    'Kurikulum',
    'Kode Mata Kuliah',
    'Nama Mata Kuliah',
    'SKS',
  ],
  title: (label) => `Mata Kuliah — ${label}`,
  orderBy: 'm.id_mk ASC',
};

const exportHandler = makeExportHandler(meta, { requireYear: false });

// Endpoint utama: /export (GET/POST) + ?format=docx|pdf + dukung id_tahun / id_tahun_in / tahun
mataKuliahRouter.get('/export', requireAuth, permit('mata_kuliah'), exportHandler);
mataKuliahRouter.post('/export', requireAuth, permit('mata_kuliah'), exportHandler);

// Alias agar FE lama yang pakai /export-doc & /export-pdf tetap jalan
mataKuliahRouter.get('/export-doc', requireAuth, permit('mata_kuliah'), makeDocAlias(exportHandler));
mataKuliahRouter.post('/export-doc', requireAuth, permit('mata_kuliah'), makeDocAlias(exportHandler));
mataKuliahRouter.get('/export-pdf', requireAuth, permit('mata_kuliah'), makePdfAlias(exportHandler));
mataKuliahRouter.post('/export-pdf', requireAuth, permit('mata_kuliah'), makePdfAlias(exportHandler));

export default mataKuliahRouter;
