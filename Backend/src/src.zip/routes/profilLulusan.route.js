import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';
import { pool } from '../db.js';
import { makeExportHandler, makeDocAlias, makePdfAlias } from '../utils/exporter.js';

export const profilLulusanRouter = Router();

const listProfilLulusan = async (req, res) => {
  const q = req.query || {};
  const idKurikulumParam = q.id_kurikulum ?? null;

  let sql = `
    SELECT
      pl.*,
      k.nama_kurikulum
    FROM profil_lulusan pl
    LEFT JOIN kurikulum k ON pl.id_kurikulum = k.id_kurikulum
  `;
  const where = [];
  const params = [];

  if (idKurikulumParam) {
    where.push('pl.id_kurikulum = ?');
    params.push(idKurikulumParam);
  }

  if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
  sql += ` ORDER BY pl.id_pl ASC`;

  try {
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal memuat data profil lulusan' });
  }
};

const crud = crudFactory({
  table: 'profil_lulusan',
  idCol: 'id_pl',
  allowedCols: ['id_kurikulum', 'kode_pl', 'deskripsi_pl'],
  resourceKey: 'profil_lulusan',
  list: listProfilLulusan,
});

// ---- CRUD ----
profilLulusanRouter.get('/', requireAuth, permit('profil_lulusan'), crud.list);
profilLulusanRouter.get('/:id(\d+)', requireAuth, permit('profil_lulusan'), crud.getById);
profilLulusanRouter.post('/', requireAuth, permit('profil_lulusan'), crud.create);
profilLulusanRouter.put('/:id(\d+)', requireAuth, permit('profil_lulusan'), crud.update);
profilLulusanRouter.delete('/:id', requireAuth, permit('profil_lulusan'), crud.remove);
profilLulusanRouter.post('/:id/restore', requireAuth, permit('profil_lulusan'), crud.restore);
profilLulusanRouter.delete('/:id/hard-delete', requireAuth, permit('profil_lulusan'), crud.hardRemove);

// ---- EXPORT (DOCX/PDF, TS-aware) ----
const meta = {
  resourceKey: 'profil_lulusan',
  table: 'profil_lulusan',
  columns: [
    'id_pl',
    'id_kurikulum',
    'kode_pl',
    'deskripsi_pl',
  ],
  headers: [
    'ID Profil Lulusan',
    'Kurikulum',
    'Kode Profil Lulusan',
    'Deskripsi Profil Lulusan',
  ],
  title: (label) => `Profil Lulusan — ${label}`,
  orderBy: 'm.id_pl ASC',
};

const exportHandler = makeExportHandler(meta, { requireYear: false });

// Endpoint utama: /export (GET/POST) + ?format=docx|pdf + dukung id_tahun / id_tahun_in / tahun
profilLulusanRouter.get('/export', requireAuth, permit('profil_lulusan'), exportHandler);
profilLulusanRouter.post('/export', requireAuth, permit('profil_lulusan'), exportHandler);

// Alias agar FE lama yang pakai /export-doc & /export-pdf tetap jalan
profilLulusanRouter.get('/export-doc', requireAuth, permit('profil_lulusan'), makeDocAlias(exportHandler));
profilLulusanRouter.post('/export-doc', requireAuth, permit('profil_lulusan'), makeDocAlias(exportHandler));
profilLulusanRouter.get('/export-pdf', requireAuth, permit('profil_lulusan'), makePdfAlias(exportHandler));
profilLulusanRouter.post('/export-pdf', requireAuth, permit('profil_lulusan'), makePdfAlias(exportHandler));

export default profilLulusanRouter;
