import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';
import { pool } from '../db.js';
import { makeExportHandler, makeDocAlias, makePdfAlias } from '../utils/exporter.js';

export const tabel2a3KondisiMahasiswaRouter = Router();

const listTabel2a3KondisiMahasiswa = async (req, res) => {
  const q = req.query || {};
  const idUnitProdiParam = q.id_unit_prodi ?? null;
  const idTahunParam = q.id_tahun ?? q.tahun ?? null;

  let sql = `
    SELECT
      km.*,
      uk.nama_unit AS nama_unit_prodi,
      ta.tahun AS tahun_akademik
    FROM tabel_2a3_kondisi_mahasiswa km
    LEFT JOIN unit_kerja uk ON km.id_unit_prodi = uk.id_unit
    LEFT JOIN tahun_akademik ta ON km.id_tahun = ta.id_tahun
  `;
  const where = [];
  const params = [];

  if (idUnitProdiParam) {
    where.push('km.id_unit_prodi = ?');
    params.push(idUnitProdiParam);
  }
  if (idTahunParam) {
    where.push('km.id_tahun = ?');
    params.push(idTahunParam);
  }

  if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
  sql += ` ORDER BY km.id ASC`;

  try {
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal memuat data kondisi mahasiswa' });
  }
};

const crud = crudFactory({
  table: 'tabel_2a3_kondisi_mahasiswa',
  idCol: 'id',
  allowedCols: [
    'id_unit_prodi',
    'id_tahun',
    'jml_aktif',
    'jml_lulus',
    'jml_do',
  ],
  resourceKey: 'tabel_2a3_kondisi_mahasiswa',
  list: listTabel2a3KondisiMahasiswa,
});

// ---- CRUD ----
tabel2a3KondisiMahasiswaRouter.get('/', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.list);
tabel2a3KondisiMahasiswaRouter.get('/:id(\d+)', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.getById);
tabel2a3KondisiMahasiswaRouter.post('/', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.create);
tabel2a3KondisiMahasiswaRouter.put('/:id(\d+)', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.update);
tabel2a3KondisiMahasiswaRouter.delete('/:id', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.remove);
tabel2a3KondisiMahasiswaRouter.post('/:id/restore', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.restore);
tabel2a3KondisiMahasiswaRouter.delete('/:id/hard-delete', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), crud.hardRemove);

// ---- EXPORT (DOCX/PDF, TS-aware) ----
const meta = {
  resourceKey: 'tabel_2a3_kondisi_mahasiswa',
  table: 'tabel_2a3_kondisi_mahasiswa',
  columns: [
    'id',
    'id_unit_prodi',
    'id_tahun',
    'jml_aktif',
    'jml_lulus',
    'jml_do',
  ],
  headers: [
    'ID',
    'Unit Prodi',
    'Tahun',
    'Jumlah Aktif',
    'Jumlah Lulus',
    'Jumlah DO',
  ],
  title: (label) => `Kondisi Mahasiswa — ${label}`,
  orderBy: 'm.id ASC',
};

const exportHandler = makeExportHandler(meta, { requireYear: true });

// Endpoint utama: /export (GET/POST) + ?format=docx|pdf + dukung id_tahun / id_tahun_in / tahun
tabel2a3KondisiMahasiswaRouter.get('/export', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), exportHandler);
tabel2a3KondisiMahasiswaRouter.post('/export', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), exportHandler);

// Alias agar FE lama yang pakai /export-doc & /export-pdf tetap jalan
tabel2a3KondisiMahasiswaRouter.get('/export-doc', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makeDocAlias(exportHandler));
tabel2a3KondisiMahasiswaRouter.post('/export-doc', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makeDocAlias(exportHandler));
tabel2a3KondisiMahasiswaRouter.get('/export-pdf', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makePdfAlias(exportHandler));
tabel2a3KondisiMahasiswaRouter.post('/export-pdf', requireAuth, permit('tabel_2a3_kondisi_mahasiswa'), makePdfAlias(exportHandler));

export default tabel2a3KondisiMahasiswaRouter;
