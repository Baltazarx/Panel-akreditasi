import { useEffect, useMemo, useState } from "react";
import { useApi } from "../../hooks/useApi";
import { useAuth } from "../../hooks/useAuth";
import { Table, TableBody, TableCell, TableHeadGroup, TableRow, TableTh } from "../ui";

// Helper functions for building table headers, copied from Tabel2A1.jsx for styling consistency.
const seg = (n) => (n.key ? String(n.key) : String(n.label || "col")).replace(/\s+/g, "_");
const depth = (n) => (n.children ? 1 + Math.max(...n.children.map(depth)) : 1);
const colSpan = (n) => (n.children ? n.children.reduce((s, c) => s + colSpan(c), 0) : 1);

const buildHeaderRows = (tree) => {
  const treeMax = Math.max(...tree.map(depth));
  const rows = [];
  const walk = (nodes, d = 1, path = []) => {
    rows[d - 1] ||= [];
    nodes.forEach((n) => {
      const hasKids = !!n.children;
      const cs = colSpan(n);
      const rs = hasKids ? 1 : treeMax - d + 1;
      const keyPath = [...path, seg(n)].join(">");

      rows[d - 1].push(
        <TableTh
          key={`th:${keyPath}:${d}`}
          colSpan={cs}
          rowSpan={rs}
          className="text-center border font-semibold tracking-wide"
        >
          {(n.label || n.key)?.toUpperCase()}
        </TableTh>
      );
      if (hasKids) walk(n.children, d + 1, [...path, seg(n)]);
    });
  };
  walk(tree);
  return rows;
};

const flattenLeaves = (tree) => {
  const out = [];
  const walk = (nodes, path = []) => {
    nodes.forEach((n) => {
      const p = [...path, seg(n)];
      if (n.children) walk(n.children, p);
      else out.push({ ...n, __path: p.join(">") });
    });
  };
  walk(tree);
  return out;
};

export function Tabel2B3() {
  const { user } = useAuth();
  const api = useApi();

  const [cplList, setCplList] = useState([]);
  const [cpmkList, setCpmkList] = useState([]); // Assuming CPMK data comes separately or from mata_kuliah
  const [mapCplMkList, setMapCplMkList] = useState([]);
  const [mataKuliahList, setMataKuliahList] = useState([]); // To get MK details
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTahun, setSelectedTahun] = useState(null);
  const [tahunList, setTahunList] = useState([]);

  const refresh = async () => {
    setLoading(true);
    setError(null);
    try {
      const [cpl, cpmk, mapCplMk, mk, t] = await Promise.all([
        api.get("/cpl"),
        api.get("/cpmk"), // Assuming a /cpmk endpoint exists
        api.get("/map-cpl-mk"),
        api.get("/mata-kuliah"), // Assuming a /mata-kuliah endpoint exists
        api.get("/tahun"),
      ]);
      setCplList(Array.isArray(cpl) ? cpl : []);
      setCpmkList(Array.isArray(cpmk) ? cpmk : []);
      setMapCplMkList(Array.isArray(mapCplMk) ? mapCplMk : []);
      setMataKuliahList(Array.isArray(mk) ? mk : []);
      setTahunList(Array.isArray(t) ? t.sort((a, b) => a.id_tahun - b.id_tahun) : []);

      const years = [...mapCplMk]
        .map((x) => Number(x?.id_tahun))
        .filter((n) => Number.isFinite(n));
      const latest = years.length === 0 ? new Date().getFullYear() : Math.max(...years);
      setSelectedTahun(latest);

    } catch (e) {
      console.error("Failed to fetch data:", e);
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api]);

  const COLS_2B3 = useMemo(() => {
    const semesterColumns = [];
    for (let i = 1; i <= 8; i++) {
      semesterColumns.push({ key: `semester_${i}`, label: `Semester ${i}` });
    }

    return [
      { key: "cpl", label: "CPL" },
      { key: "cpmk", label: "CPMK" },
      ...semesterColumns,
    ];
  }, []);

  const headerRows = useMemo(() => buildHeaderRows(COLS_2B3), [COLS_2B3]);
  const leaves = useMemo(() => flattenLeaves(COLS_2B3), [COLS_2B3]);

  const displayRows = useMemo(() => {
    if (!selectedTahun || !user?.unit_id) return [];

    const filteredMapping = mapCplMkList.filter(
      (map) => Number(map.id_tahun) === Number(selectedTahun) && map.id_unit_prodi === user.unit_id
    );

    const rows = [];
    cplList.forEach(cpl => {
      // Get CPMKs associated with this CPL (assuming CPMK objects have id_cpl)
      const associatedCpmks = cpmkList.filter(cpmk => cpmk.id_cpl === cpl.id_cpl);

      if (associatedCpmks.length === 0) {
        // If no CPMK, create a row just for CPL
        const newRow = { cpl: cpl.kode_cpl || `CPL ${cpl.id_cpl}`, cpmk: "" };
        for (let i = 1; i <= 8; i++) {
          newRow[`semester_${i}`] = "";
        }
        rows.push(newRow);
      } else {
        associatedCpmks.forEach(cpmk => {
          const newRow = { cpl: cpl.kode_cpl || `CPL ${cpl.id_cpl}`, cpmk: cpmk.kode_cpmk || `CPMK ${cpmk.id_cpmk}` };
          for (let i = 1; i <= 8; i++) {
            newRow[`semester_${i}`] = "";
          }

          // Find relevant mata kuliah for this CPL-CPMK-Tahun-Unit combination
          const relevantMkMappings = filteredMapping.filter(
            (map) => map.id_cpl === cpl.id_cpl && map.id_cpmk === cpmk.id_cpmk
          );

          relevantMkMappings.forEach(map => {
            const mataKuliah = mataKuliahList.find(mk => mk.id_mata_kuliah === map.id_mata_kuliah);
            if (mataKuliah && mataKuliah.semester) {
              const semesterKey = `semester_${mataKuliah.semester}`;
              if (newRow[semesterKey]) {
                newRow[semesterKey] += `, ${mataKuliah.kode_mk || mataKuliah.nama_mk}`;
              } else {
                newRow[semesterKey] = mataKuliah.kode_mk || mataKuliah.nama_mk;
              }
            }
          });
          rows.push(newRow);
        });
      }
    });
    return rows;

  }, [cplList, cpmkList, mapCplMkList, mataKuliahList, selectedTahun, user?.unit_id]);

  const renderBody = (rows, leaves) =>
    rows.map((item, rowIndex) => {
      const rowKey = `row-${item.cpl}-${item.cpmk}-${rowIndex}`;
      return (
        <TableRow
          key={rowKey}
          className="odd:bg-white even:bg-gray-50 dark:odd:bg-white/5 dark:even:bg-white/10 hover:bg-indigo-50/60 dark:hover:bg-indigo-500/10 transition"
        >
          {leaves.map((leaf) => {
            const cellKey = `td:${leaf.__path}:${rowKey}`;
            let content = item[leaf.key] || "";

            return (
              <TableCell
                key={cellKey}
                className={`border align-middle ${leaf.key === "cpl" || leaf.key === "cpmk" ? "text-left pl-4 font-medium text-gray-900 dark:text-white" : "text-center"}`}
              >
                {content}
              </TableCell>
            );
          })}
        </TableRow>
      );
    });

  if (loading) return <div>Memuat data...</div>;
  if (error) return <div>Error: {String(error?.message || error)}</div>;

  return (
    <div className="w-full overflow-x-auto mb-10 rounded-2xl border border-gray-200 overflow-hidden shadow-lg">
      <div className="flex justify-between items-center bg-gray-100 dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Tabel 2.B.3 Peta Pemenuhan CPL</h3>
        <div className="flex items-center space-x-2">
          <label htmlFor="select-tahun" className="text-gray-700 dark:text-gray-300 font-medium">Pilih Tahun:</label>
          <select
            id="select-tahun"
            className="py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-gray-700 text-white"
            value={selectedTahun || ''}
            onChange={(e) => setSelectedTahun(Number(e.target.value))}
          >
            <option value="" disabled>Pilih Tahun</option>
            {tahunList.map((tahun) => (
              <option key={tahun.id_tahun} value={tahun.id_tahun}>
                {tahun.tahun}
              </option>
            ))}
          </select>
        </div>
      </div>
      <Table className="min-w-full text-sm border-collapse border-0">
        <TableHeadGroup>
          {headerRows.map((cells, idx) => (
            <TableRow
              key={`hdr:Tabel_2B3:${idx}`}
              className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white sticky top-0"
            >
              {cells}
            </TableRow>
          ))}
        </TableHeadGroup>
        <TableBody>{renderBody(displayRows, leaves)}</TableBody>
      </Table>
    </div>
  );
}

export default Tabel2B3;
