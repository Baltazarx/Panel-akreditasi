import { useEffect, useMemo, useState } from "react";
import { useApi } from "../../hooks/useApi";
import { useAuth } from "../../hooks/useAuth";
import { Table, TableBody, TableCell, TableHeadGroup, TableRow, TableTh } from "../ui";

// Helper functions for building table headers, copied from Tabel2A1.jsx for styling consistency.
const seg = (n) => (n.key ? String(n.key) : String(n.label || "col")).replace(/\s+/g, "_");
const depth = (n) => (n.children ? 1 + Math.max(...n.children.map(depth)) : 1);
const colSpan = (n) => (n.children ? n.children.reduce((s, c) => s + colSpan(c), 0) : 1);

const buildHeaderRows = (tree) => {
  const treeMax = Math.max(...tree.map(depth));
  const rows = [];
  const walk = (nodes, d = 1, path = []) => {
    rows[d - 1] ||= [];
    nodes.forEach((n) => {
      const hasKids = !!n.children;
      const cs = colSpan(n);
      const rs = hasKids ? 1 : treeMax - d + 1;
      const keyPath = [...path, seg(n)].join(">");

      rows[d - 1].push(
        <TableTh
          key={`th:${keyPath}:${d}`}
          colSpan={cs}
          rowSpan={rs}
          className="text-center border font-semibold tracking-wide"
        >
          {(n.label || n.key)?.toUpperCase()}
        </TableTh>
      );
      if (hasKids) walk(n.children, d + 1, [...path, seg(n)]);
    });
  };
  walk(tree);
  return rows;
};

const flattenLeaves = (tree) => {
  const out = [];
  const walk = (nodes, path = []) => {
    nodes.forEach((n) => {
      const p = [...path, seg(n)];
      if (n.children) walk(n.children, p);
      else out.push({ ...n, __path: p.join(">") });
    });
  };
  walk(tree);
  return out;
};

export function Tabel2B2() {
  const { user } = useAuth();
  const api = useApi();

  const [cplList, setCplList] = useState([]);
  const [profilLulusanList, setProfilLulusanList] = useState([]);
  const [cplPlMapping, setCplPlMapping] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTahun, setSelectedTahun] = useState(null);
  const [tahunList, setTahunList] = useState([]);

  const refresh = async () => {
    setLoading(true);
    setError(null);
    try {
      const [cpl, pl, mapping, t] = await Promise.all([
        api.get("/cpl"), // Endpoint untuk daftar CPL
        api.get("/profil-lulusan"), // Endpoint untuk daftar Profil Lulusan
        api.get("/map-cpl-pl"), // Endpoint untuk pemetaan CPL ke PL
        api.get("/tahun"), // Endpoint untuk daftar tahun
      ]);
      setCplList(Array.isArray(cpl) ? cpl : []);
      setProfilLulusanList(Array.isArray(pl) ? pl : []);
      setCplPlMapping(Array.isArray(mapping) ? mapping : []);
      setTahunList(Array.isArray(t) ? t.sort((a, b) => a.id_tahun - b.id_tahun) : []);

      const years = [...mapping]
        .map((x) => Number(x?.id_tahun))
        .filter((n) => Number.isFinite(n));
      const latest = years.length === 0 ? new Date().getFullYear() : Math.max(...years);
      setSelectedTahun(latest);

    } catch (e) {
      console.error("Failed to fetch data:", e);
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api]);

  const COLS_2B2 = useMemo(() => {
    const dynamicPLColumns = profilLulusanList.map((pl, index) => ({
      key: `pl_${pl.id_pl}`, // Assuming each PL has a unique ID
      label: pl.nama_pl || `PL ${index + 1}`, // Display name or generic PL
    }));

    return [
      { key: "cpl", label: "CPL" },
      {
        label: "Profil Lulusan (PL)",
        children: dynamicPLColumns.length > 0 ? dynamicPLColumns : [{ key: "placeholder_pl", label: "..." }], // Placeholder if no PLs
      },
    ];
  }, [profilLulusanList]);

  const headerRows = useMemo(() => buildHeaderRows(COLS_2B2), [COLS_2B2]);
  const leaves = useMemo(() => flattenLeaves(COLS_2B2), [COLS_2B2]);

  const displayRows = useMemo(() => {
    if (!selectedTahun || !user?.unit_id) return [];

    // Filter mapping data by selectedTahun and user's unit_id
    const filteredMapping = cplPlMapping.filter(
      (map) => Number(map.id_tahun) === Number(selectedTahun) && map.id_unit_prodi === user.unit_id
    );

    // Create a set of mapped CPL-PL pairs for quick lookup
    const mappedPairs = new Set(filteredMapping.map(map => `${map.id_cpl}-${map.id_pl}`));

    return cplList.map(cpl => {
      const row = { cpl: cpl.kode_cpl || `CPL ${cpl.id_cpl}` }; // Assuming CPLs have a code or ID
      profilLulusanList.forEach(pl => {
        row[`pl_${pl.id_pl}`] = mappedPairs.has(`${cpl.id_cpl}-${pl.id_pl}`);
      });
      return row;
    });
  }, [cplList, profilLulusanList, cplPlMapping, selectedTahun, user?.unit_id]);

  const renderBody = (rows, leaves) =>
    rows.map((item, rowIndex) => {
      const rowKey = `row-${item.cpl}-${rowIndex}`;
      return (
        <TableRow
          key={rowKey}
          className="odd:bg-white even:bg-gray-50 dark:odd:bg-white/5 dark:even:bg-white/10 hover:bg-indigo-50/60 dark:hover:bg-indigo-500/10 transition"
        >
          {leaves.map((leaf) => {
            const cellKey = `td:${leaf.__path}:${rowKey}`;
            let content;
            if (leaf.key.startsWith("pl_")) {
              content = item[leaf.key] ? "✓" : ""; // Checkmark if CPL is mapped to PL
            } else {
              content = item[leaf.key];
            }

            return (
              <TableCell
                key={cellKey}
                className={`border align-middle ${leaf.key === "cpl" ? "text-left pl-4 font-medium text-gray-900 dark:text-white" : "text-center"}`}
              >
                {content}
              </TableCell>
            );
          })}
        </TableRow>
      );
    });

  if (loading) return <div>Memuat data...</div>;
  if (error) return <div>Error: {String(error?.message || error)}</div>;

  return (
    <div className="w-full overflow-x-auto mb-10 rounded-2xl border border-gray-200 overflow-hidden shadow-lg">
      <div className="flex justify-between items-center bg-gray-100 dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Tabel 2.B.2 Pemetaan Capaian Pembelajaran Lulusan dan Profil Lulusan</h3>
        <div className="flex items-center space-x-2">
          <label htmlFor="select-tahun" className="text-gray-700 dark:text-gray-300 font-medium">Pilih Tahun:</label>
          <select
            id="select-tahun"
            className="py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-gray-700 text-white"
            value={selectedTahun || ''}
            onChange={(e) => setSelectedTahun(Number(e.target.value))}
          >
            <option value="" disabled>Pilih Tahun</option>
            {tahunList.map((tahun) => (
              <option key={tahun.id_tahun} value={tahun.id_tahun}>
                {tahun.tahun}
              </option>
            ))}
          </select>
        </div>
      </div>
      <Table className="min-w-full text-sm border-collapse border-0">
        <TableHeadGroup>
          {headerRows.map((cells, idx) => (
            <TableRow
              key={`hdr:Tabel_2B2:${idx}`}
              className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white sticky top-0"
            >
              {cells}
            </TableRow>
          ))}
        </TableHeadGroup>
        <TableBody>{renderBody(displayRows, leaves)}</TableBody>
      </Table>
    </div>
  );
}

export default Tabel2B2;
