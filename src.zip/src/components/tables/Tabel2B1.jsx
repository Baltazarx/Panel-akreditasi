import { useEffect, useMemo, useState } from "react";
import { useApi } from "../../hooks/useApi";
import { useAuth } from "../../hooks/useAuth";
import { Table, TableBody, TableCell, TableHeadGroup, TableRow, TableTh } from "../ui";

// Helper functions for building table headers, copied from Tabel2A1.jsx for styling consistency.
const seg = (n) => (n.key ? String(n.key) : String(n.label || "col")).replace(/\s+/g, "_");
const depth = (n) => (n.children ? 1 + Math.max(...n.children.map(depth)) : 1);
const colSpan = (n) => (n.children ? n.children.reduce((s, c) => s + colSpan(c), 0) : 1);

const buildHeaderRows = (tree) => {
  const treeMax = Math.max(...tree.map(depth));
  const rows = [];
  const walk = (nodes, d = 1, path = []) => {
    rows[d - 1] ||= [];
    nodes.forEach((n) => {
      const hasKids = !!n.children;
      const cs = colSpan(n);
      const rs = hasKids ? 1 : treeMax - d + 1;
      const keyPath = [...path, seg(n)].join(">");

      rows[d - 1].push(
        <TableTh
          key={`th:${keyPath}:${d}`}
          colSpan={cs}
          rowSpan={rs}
          className="text-center border font-semibold tracking-wide"
        >
          {(n.label || n.key)?.toUpperCase()}
        </TableTh>
      );
      if (hasKids) walk(n.children, d + 1, [...path, seg(n)]);
    });
  };
  walk(tree);
  return rows;
};

const flattenLeaves = (tree) => {
  const out = [];
  const walk = (nodes, path = []) => {
    nodes.forEach((n) => {
      const p = [...path, seg(n)];
      if (n.children) walk(n.children, p);
      else out.push({ ...n, __path: p.join(">") });
    });
  };
  walk(tree);
  return out;
};

export function Tabel2B1() {
  const { user } = useAuth();
  const api = useApi();

  const [isiPembelajaran, setIsiPembelajaran] = useState([]);
  const [profilLulusanList, setProfilLulusanList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedTahun, setSelectedTahun] = useState(null);
  const [tahunList, setTahunList] = useState([]);

  const refresh = async () => {
    setLoading(true);
    setError(null);
    try {
      const [ip, pl, t] = await Promise.all([
        api.get("/tabel-2b1-isi-pembelajaran"),
        api.get("/profil-lulusan"), // Assuming an endpoint for Profil Lulusan
        api.get("/tahun"),
      ]);
      setIsiPembelajaran(Array.isArray(ip) ? ip : []);
      setProfilLulusanList(Array.isArray(pl) ? pl : []);
      setTahunList(Array.isArray(t) ? t.sort((a, b) => a.id_tahun - b.id_tahun) : []);

      const years = [...ip]
        .map((x) => Number(x?.id_tahun))
        .filter((n) => Number.isFinite(n));
      const latest = years.length === 0 ? new Date().getFullYear() : Math.max(...years);
      setSelectedTahun(latest);

    } catch (e) {
      console.error("Failed to fetch data:", e);
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [api]);

  const COLS_2B1 = useMemo(() => {
    const dynamicPLColumns = profilLulusanList.map((pl, index) => ({
      key: `pl_${pl.id_pl}`, // Assuming each PL has a unique ID
      label: pl.nama_pl || `PL ${index + 1}`, // Display name or generic PL
    }));

    return [
      { key: "no", label: "No" },
      { key: "mata_kuliah", label: "Mata Kuliah" },
      { key: "sks", label: "SKS" },
      { key: "semester", label: "Semester" },
      {
        label: "Profil Lulusan (PL)",
        children: dynamicPLColumns.length > 0 ? dynamicPLColumns : [{ key: "placeholder_pl", label: "..." }], // Placeholder if no PLs
      },
    ];
  }, [profilLulusanList]);

  const headerRows = useMemo(() => buildHeaderRows(COLS_2B1), [COLS_2B1]);
  const leaves = useMemo(() => flattenLeaves(COLS_2B1), [COLS_2B1]);

  const filterAndMapData = useMemo(() => {
    if (!selectedTahun || !user?.unit_id) return [];

    const filteredData = isiPembelajaran.filter(
      (item) => Number(item.id_tahun) === Number(selectedTahun) && item.id_unit_prodi === user.unit_id
    );

    // Grouping by mata_kuliah and semester
    const grouped = {};
    filteredData.forEach(item => {
      const key = `${item.id_mata_kuliah}-${item.semester}`; // Assuming unique mata_kuliah + semester combination
      if (!grouped[key]) {
        grouped[key] = {
          no: Object.keys(grouped).length + 1, // Simple numbering for display
          mata_kuliah: item.nama_mata_kuliah, // Assuming nama_mata_kuliah is available
          sks: item.sks,
          semester: item.semester,
        };
        profilLulusanList.forEach(pl => {
          grouped[key][`pl_${pl.id_pl}`] = false; // Initialize PL columns as false (checkbox/boolean)
        });
      }
      // Set the corresponding PL to true if there's a mapping
      if (item.id_pl && profilLulusanList.some(pl => pl.id_pl === item.id_pl)) {
        grouped[key][`pl_${item.id_pl}`] = true;
      }
    });

    return Object.values(grouped);
  }, [isiPembelajaran, selectedTahun, user?.unit_id, profilLulusanList]);

  const renderBody = (rows, leaves) =>
    rows.map((item, rowIndex) => {
      const rowKey = `row-${item.mata_kuliah}-${item.semester}-${rowIndex}`;
      return (
        <TableRow
          key={rowKey}
          className="odd:bg-white even:bg-gray-50 dark:odd:bg-white/5 dark:even:bg-white/10 hover:bg-indigo-50/60 dark:hover:bg-indigo-500/10 transition"
        >
          {leaves.map((leaf) => {
            const cellKey = `td:${leaf.__path}:${rowKey}`;
            let content;
            if (leaf.key.startsWith("pl_")) {
              content = item[leaf.key] ? "✓" : ""; // Checkmark if PL is mapped
            } else {
              content = item[leaf.key];
            }

            return (
              <TableCell
                key={cellKey}
                className={`border align-middle ${leaf.key === "mata_kuliah" ? "text-left pl-4 font-medium text-gray-900 dark:text-white" : "text-center"}`}
              >
                {content}
              </TableCell>
            );
          })}
        </TableRow>
      );
    });

  if (loading) return <div>Memuat data...</div>;
  if (error) return <div>Error: {String(error?.message || error)}</div>;

  return (
    <div className="w-full overflow-x-auto mb-10 rounded-2xl border border-gray-200 overflow-hidden shadow-lg">
      <div className="flex justify-between items-center bg-gray-100 dark:bg-gray-800 p-4 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Tabel 2.B.1 Tabel Isi Pembelajaran</h3>
        <div className="flex items-center space-x-2">
          <label htmlFor="select-tahun" className="text-gray-700 dark:text-gray-300 font-medium">Pilih Tahun:</label>
          <select
            id="select-tahun"
            className="py-2 px-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm bg-gray-700 text-white"
            value={selectedTahun || ''}
            onChange={(e) => setSelectedTahun(Number(e.target.value))}
          >
            <option value="" disabled>Pilih Tahun</option>
            {tahunList.map((tahun) => (
              <option key={tahun.id_tahun} value={tahun.id_tahun}>
                {tahun.tahun}
              </option>
            ))}
          </select>
        </div>
      </div>
      <Table className="min-w-full text-sm border-collapse border-0">
        <TableHeadGroup>
          {headerRows.map((cells, idx) => (
            <TableRow
              key={`hdr:Tabel_2B1:${idx}`}
              className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white sticky top-0"
            >
              {cells}
            </TableRow>
          ))}
        </TableHeadGroup>
        <TableBody>{renderBody(filterAndMapData, leaves)}</TableBody>
      </Table>
    </div>
  );
}

export default Tabel2B1;
