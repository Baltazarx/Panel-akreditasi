import { Router } from 'express';
import { crudFactory } from '../utils/crudFactory.js';
import { requireAuth } from '../auth/auth.middleware.js';
import { permit } from '../rbac/permit.middleware.js';
import { pool } from '../db.js';
import { makeExportHandler, makeDocAlias, makePdfAlias } from '../utils/exporter.js';

export const mataKuliahRouter = Router();

const listMataKuliah = async (req, res) => {
  const q = req.query || {};
  const idUnitProdiParam = q.id_unit_prodi ?? null;
  const idTahunParam = q.id_tahun ?? null;

  let sql = `
    SELECT
      mk.id_mk,
      mk.kode_mk,
      mk.nama_mk,
      mk.sks,
      mk.semester,
      mk.id_unit_prodi,
      COALESCE(direct_pl.selectedPls, indirect_pl.selectedPls) AS selectedPls,
      GROUP_CONCAT(DISTINCT c.kode_cpl ORDER BY c.kode_cpl ASC) AS relatedCpls
    FROM mata_kuliah mk
    LEFT JOIN (
      SELECT id_mk, GROUP_CONCAT(DISTINCT id_pl ORDER BY id_pl ASC) AS selectedPls
      FROM map_mk_pl
      GROUP BY id_mk
    ) direct_pl ON mk.id_mk = direct_pl.id_mk
    LEFT JOIN map_cpl_mk mcmk ON mk.id_mk = mcmk.id_mk
    LEFT JOIN cpl c ON mcmk.id_cpl = c.id_cpl
    LEFT JOIN map_cpl_pl mcpp ON c.id_cpl = mcpp.id_cpl
    LEFT JOIN profil_lulusan pl ON mcpp.id_pl = pl.id_pl
    LEFT JOIN (
      SELECT mcmk2.id_mk, GROUP_CONCAT(DISTINCT pl2.id_pl ORDER BY pl2.id_pl ASC) AS selectedPls
      FROM map_cpl_mk mcmk2
      JOIN cpl c2 ON mcmk2.id_cpl = c2.id_cpl
      JOIN map_cpl_pl mcpp2 ON c2.id_cpl = mcpp2.id_cpl
      JOIN profil_lulusan pl2 ON mcpp2.id_pl = pl2.id_pl
      GROUP BY mcmk2.id_mk
    ) indirect_pl ON mk.id_mk = indirect_pl.id_mk
  `;
  const where = [];
  const params = [];

  // if (idTahunParam) {
  //   params.push(idTahunParam);
  // } else {
  //   params.push(new Date().getFullYear());
  // }

  // Filter additional parameters here if needed (e.g., id_unit_prodi)
  if (idUnitProdiParam) {
    where.push('mk.id_unit_prodi = ?');
    params.push(idUnitProdiParam);
  }

  if (where.length) sql += ` WHERE ${where.join(' AND ')}`;
  sql += ` GROUP BY mk.id_mk, mk.kode_mk, mk.nama_mk, mk.sks, mk.semester, mk.id_unit_prodi`;
  sql += ` ORDER BY mk.id_mk ASC`;

  try {
    const [rows] = await pool.query(sql, params);
    console.log("Backend: Data fetched for /mata-kuliah:", rows);

    // Proses hasil untuk mengubah selectedPls dan relatedCpls dari string menjadi array
    const processedRows = rows.map(row => ({
      ...row,
      selectedPls: row.selectedPls ? String(row.selectedPls).split(',').map(Number) : [],
      relatedCpls: row.relatedCpls ? String(row.relatedCpls).split(',').filter(c => c) : [],
    }));

    console.log("Backend: Processed mata kuliah data:", processedRows.map(row => ({
      id_mk: row.id_mk,
      nama_mk: row.nama_mk,
      prodi: row.id_unit_prodi,
      selectedPls: row.selectedPls,
      relatedCpls: row.relatedCpls
    })));

    res.json(processedRows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal memuat data mata kuliah' });
  }
};

const crud = crudFactory({
  table: 'mata_kuliah',
  idCol: 'id_mk',
  allowedCols: ['nama_mk', 'sks', 'semester', 'id_unit_prodi'],
  resourceKey: 'mata_kuliah',
  list: listMataKuliah,
});

// ---- CRUD ----
mataKuliahRouter.get('/', requireAuth, permit('mata_kuliah'), crud.list);
mataKuliahRouter.get('/:id(\d+)', requireAuth, permit('mata_kuliah'), crud.getById);
mataKuliahRouter.post('/', requireAuth, permit('mata_kuliah'), async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const { id_unit_prodi, nama_mk, sks, semester, selectedPls = [] } = req.body; 

    // 2. Buat mata kuliah baru
    const [result] = await connection.query(
      `INSERT INTO mata_kuliah (id_unit_prodi, kode_mk, nama_mk, sks, semester) VALUES (?, ?, ?, ?, ?)`,
      [id_unit_prodi, 'GEN-' + Date.now(), nama_mk, sks, semester]
    );

    const id_mk = result.insertId;

    // 3. Simpan pemetaan langsung ke map_mk_pl (jika ada selectedPls)
    if (selectedPls && selectedPls.length > 0) {
      // Validate that all selected PLs exist for this prodi
      const [validPlRows] = await connection.query(
        `SELECT id_pl, kode_pl FROM profil_lulusan WHERE id_unit_prodi = ? AND id_pl IN (${selectedPls.map(() => '?').join(',')})`,
        [id_unit_prodi, ...selectedPls]
      );

      const validPlIds = validPlRows.map(row => row.id_pl);
      const invalidPlIds = selectedPls.filter(plId => !validPlIds.includes(plId));

      if (invalidPlIds.length > 0) {
        console.error(`MataKuliah POST: Invalid PL IDs for prodi ${id_unit_prodi}:`, invalidPlIds);
        return res.status(400).json({
          error: `PL dengan ID berikut tidak valid untuk prodi ini: ${invalidPlIds.join(', ')}`
        });
      }

      // Simpan pemetaan langsung ke map_mk_pl
      for (const plId of selectedPls) {
        await connection.query(
          `INSERT INTO map_mk_pl (id_mk, id_pl) VALUES (?, ?)`,
          [id_mk, plId]
        );
      }

      // Also maintain the CPL mapping for backward compatibility
      const uniqueCplIds = new Set();
      for (const plId of selectedPls) {
        console.log(`MataKuliah POST: Mencari CPL untuk id_unit_prodi=${id_unit_prodi}, plId=${plId}`);
        const [cplRows] = await connection.query(
          `SELECT mc.id_cpl, mc.kode_cpl FROM cpl mc JOIN map_cpl_pl mcpp ON mc.id_cpl = mcpp.id_cpl WHERE mc.id_unit_prodi = ? AND mcpp.id_pl = ?`,
          [id_unit_prodi, plId]
        );

        if (cplRows.length > 0) {
          uniqueCplIds.add(cplRows[0].id_cpl);
          console.log(`MataKuliah POST: Ditemukan CPL ${cplRows[0].kode_cpl} untuk PL ${plId}`);
        }
      }

      // Sisipkan hanya id_cpl yang unik ke map_cpl_mk
      for (const cplId of uniqueCplIds) {
        await connection.query(
          `INSERT INTO map_cpl_mk (id_cpl, id_mk) VALUES (?, ?)`,
          [cplId, id_mk]
        );
      }
    }

    await connection.commit();
    res.status(201).json({ id_mk, message: 'Mata Kuliah berhasil ditambahkan' });
  } catch (e) {
    await connection.rollback();
    console.error(e);
    res.status(500).json({ error: 'Gagal menambahkan mata kuliah' });
  } finally {
    connection.release();
  }
});

const updateMataKuliah = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const { id } = req.params;
    const { nama_mk, sks, semester, id_unit_prodi, selectedPls = [] } = req.body; // id_tahun dihapus dari sini

    // 1. Perbarui data dasar mata kuliah
    await connection.query(
      `UPDATE mata_kuliah SET nama_mk = ?, sks = ?, semester = ?, id_unit_prodi = ? WHERE id_mk = ?`,
      [nama_mk, sks, semester, id_unit_prodi, id]
    );

    // 2. Hapus pemetaan yang ada
    await connection.query(`DELETE FROM map_cpl_mk WHERE id_mk = ?`, [id]);
    await connection.query(`DELETE FROM map_mk_pl WHERE id_mk = ?`, [id]);

    // 3. Sisipkan pemetaan baru
    if (selectedPls && selectedPls.length > 0) {
      // Validate that all selected PLs exist for this prodi
      const [validPlRows] = await connection.query(
        `SELECT id_pl, kode_pl FROM profil_lulusan WHERE id_unit_prodi = ? AND id_pl IN (${selectedPls.map(() => '?').join(',')})`,
        [id_unit_prodi, ...selectedPls]
      );

      const validPlIds = validPlRows.map(row => row.id_pl);
      const invalidPlIds = selectedPls.filter(plId => !validPlIds.includes(plId));

      if (invalidPlIds.length > 0) {
        console.error(`MataKuliah PUT: Invalid PL IDs for prodi ${id_unit_prodi}:`, invalidPlIds);
        return res.status(400).json({
          error: `PL dengan ID berikut tidak valid untuk prodi ini: ${invalidPlIds.join(', ')}`
        });
      }

      const uniqueCplIds = new Set(); // Menggunakan Set untuk menyimpan id_cpl unik
      for (const plId of selectedPls) {
        console.log(`MataKuliah PUT: Mencari CPL untuk id_unit_prodi=${id_unit_prodi}, plId=${plId}`);
        const [cplRows] = await connection.query(
          `SELECT mc.id_cpl, mc.kode_cpl FROM cpl mc JOIN map_cpl_pl mcpp ON mc.id_cpl = mcpp.id_cpl WHERE mc.id_unit_prodi = ? AND mcpp.id_pl = ?`,
          [id_unit_prodi, plId]
        );

        if (cplRows.length > 0) {
          uniqueCplIds.add(cplRows[0].id_cpl); // Tambahkan ke Set CPL unik
          console.log(`MataKuliah PUT: Ditemukan CPL ${cplRows[0].kode_cpl} untuk PL ${plId}`);
        } else {
          console.warn(`CPL tidak ditemukan untuk id_pl: ${plId} di unit prodi: ${id_unit_prodi}`);
          // Coba cari PL untuk memverifikasi
          const [plRows] = await connection.query(
            `SELECT kode_pl FROM profil_lulusan WHERE id_pl = ? AND id_unit_prodi = ?`,
            [plId, id_unit_prodi]
          );
          if (plRows.length > 0) {
            const plKode = plRows[0].kode_pl;
            console.log(`MataKuliah PUT: PL ${plKode} ditemukan tapi tidak ada CPL yang ter-mapping`);

            // Try to find a CPL that matches the PL naming pattern
            const [matchingCplRows] = await connection.query(
              `SELECT id_cpl, kode_cpl FROM cpl WHERE id_unit_prodi = ? AND kode_cpl LIKE ?`,
              [id_unit_prodi, `%${plKode.split('-')[1]}%`] // Match by the numeric part
            );

            if (matchingCplRows.length > 0) {
              uniqueCplIds.add(matchingCplRows[0].id_cpl);
              console.log(`MataKuliah PUT: Auto-mapped PL ${plKode} to CPL ${matchingCplRows[0].kode_cpl}`);
            } else {
              console.warn(`MataKuliah PUT: Tidak dapat menemukan CPL yang sesuai untuk PL ${plKode}. Perlu mapping manual.`);
            }
          } else {
            console.error(`MataKuliah PUT: PL dengan id ${plId} tidak ditemukan di unit prodi ${id_unit_prodi}`);
          }
        }
      }

      // Sisipkan hanya id_cpl yang unik ke map_cpl_mk
      for (const cplId of uniqueCplIds) {
        await connection.query(
          `INSERT INTO map_cpl_mk (id_cpl, id_mk) VALUES (?, ?)`,
          [cplId, id]
        );
      }
    }

    await connection.commit();
    res.json({ message: 'Mata Kuliah berhasil diperbarui' });
  } catch (e) {
    await connection.rollback();
    console.error(e);
    res.status(500).json({ error: 'Gagal memperbarui mata kuliah' });
  } finally {
    connection.release();
  }
};

mataKuliahRouter.put('/:id', requireAuth, permit('mata_kuliah'), updateMataKuliah);
mataKuliahRouter.delete('/:id', requireAuth, permit('mata_kuliah'), crud.remove);
mataKuliahRouter.post('/:id/restore', requireAuth, permit('mata_kuliah'), crud.restore);
mataKuliahRouter.delete('/:id/hard-delete', requireAuth, permit('mata_kuliah'), crud.hardRemove);

// ---- EXPORT (DOCX/PDF, TS-aware) ----
const meta = {
  resourceKey: 'mata_kuliah',
  table: 'mata_kuliah',
  columns: [
    'id_mk',
    'kode_mk',
    'nama_mk',
    'sks',
  ],
  headers: [
    'ID Mata Kuliah',
    'Kode Mata Kuliah',
    'Nama Mata Kuliah',
    'SKS',
  ],
  title: (label) => `Mata Kuliah — ${label}`,
  orderBy: 'm.id_mk ASC',
};

const exportHandler = makeExportHandler(meta, { requireYear: false });

// Endpoint utama: /export (GET/POST) + ?format=docx|pdf + dukung id_tahun / id_tahun_in / tahun
mataKuliahRouter.get('/export', requireAuth, permit('mata_kuliah'), exportHandler);
mataKuliahRouter.post('/export', requireAuth, permit('mata_kuliah'), exportHandler);

// Alias agar FE lama yang pakai /export-doc & /export-pdf tetap jalan
mataKuliahRouter.get('/export-doc', requireAuth, permit('mata_kuliah'), makeDocAlias(exportHandler));
mataKuliahRouter.post('/export-doc', requireAuth, permit('mata_kuliah'), makeDocAlias(exportHandler));
mataKuliahRouter.get('/export-pdf', requireAuth, permit('mata_kuliah'), makePdfAlias(exportHandler));
mataKuliahRouter.post('/export-pdf', requireAuth, permit('mata_kuliah'), makePdfAlias(exportHandler));

export default mataKuliahRouter;